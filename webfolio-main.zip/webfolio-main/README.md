# **WEBFÓLIO ADILIA UAMUSSE - 2023**

![](./img/DESKTOP.png)

## [Clique aqui](https://adiliauamusse.github.io/webfolio/) para acessar o site

## **SOBRE**

- Site tipo do webfólio, onde foi construído como trabalho academico




## **TECNOLOGIAS APLICADAS**

- HTML5
- CSS3


## **FERRAMENTAS**

- VSCODE
- GITHUB / GIT
- FIGMA
- FONT-AWESOME


## **CONCEITOS APLICADOS**

- DISPLAY (GRID)
- GRID (AREA)
- CSS PORCIONADO
- @MEDIA

## **AUTOR**

- [ADILIA UAMUSSE](https://github.com/adiliauamusse)

